def receive():
    print("接收成功")