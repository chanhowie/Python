from distutils.core import setup
setup(name="ceshi",
      version="1.0",
      description="简短的说明测试打包",
      long_description="完整的说明测试打包",
      author="作者是我",
      author_email="作者的邮箱",
      url="主页www.baidu.com",
      py_modules=["ceshibao.send_message",
                   "ceshibao.receive_message"])